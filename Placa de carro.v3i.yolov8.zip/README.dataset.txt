# Placa de carro  > 2024-01-09 8:42pm
https://universe.roboflow.com/trabalho-jnal6/placa-de-carro-oz0eg

Provided by a Roboflow user
License: CC BY 4.0

